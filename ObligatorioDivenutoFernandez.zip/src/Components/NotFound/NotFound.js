import React from 'react'

export const NotFound = () => {
  return (
    <div>Oooops no se encontró la página solicitada</div>
  )
}
